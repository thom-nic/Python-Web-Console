import os
import sys
path = os.path.abspath("/from_SyspathAppendingInitializer_with_love")
assert path in sys.path
